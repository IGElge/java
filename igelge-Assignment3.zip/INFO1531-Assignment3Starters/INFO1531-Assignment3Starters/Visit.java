/*
NAME: Isabella Elge
DATE:09/22/2025
CLASS: INFO 1531
ASSIGNMENT: Assignment 3 - Pet Schedule
RESOURCES: I utilized the book and the lecture for this assignment

PURPOSE:Stores unique information for the pet entity as well as compares visits to eachother
 */

/**
 * YOUR TODO
 *
 * Implement the comparable interface and compare to method here
 *
 * Object for the visit of a pet to the vet.
 */
//declares a public class and implements visit
public class Visit implements Comparable<Visit> {
    //sets variables and their respective types
    private int id;
    private String date;
    private String time;
    private int animalID;
    private String details;
//an override for the date
    @Override
    //compares the date to another date
    public int compareTo(Visit other) {
        //formats the dates to have - between the day month year
        String[] thisParts = this.date.split("-");
        String[] otherParts = other.date.split("-");
//converts each part of date into the parts (day =0, month =1, year=2)
        int thisDay = Integer.parseInt(thisParts[0]);
        int thisMonth = Integer.parseInt(thisParts[1]);
        int thisYear = Integer.parseInt(thisParts[2]);

        int otherDay = Integer.parseInt(otherParts[0]);
        int otherMonth = Integer.parseInt(otherParts[1]);
        int otherYear = Integer.parseInt(otherParts[2]);

        // Compare by year, then month, then day
        if (thisYear != otherYear) {
            return Integer.compare(thisYear, otherYear);
        }
        if (thisMonth != otherMonth) {
            return Integer.compare(thisMonth, otherMonth);
        }
        return Integer.compare(thisDay, otherDay);
    }
    /**
     * Main constructor
     * @param date String for the date
     * @param time String for the time
     * @param animalID int for the animal ID to link this visit to
     * @param details String of the details about the visit
     */
    public Visit(int id, String date, String time, int animalID, String details) {
        this.id = id;
        this.date = date;
        this.time = time;
        this.animalID = animalID;
        this.details = details;
    }

    /**
     * Returns the id of the visit
     * @return int for the id
     */
    public int getId() {
        return id;
    }

    /**
     * Changes the id
     * @param id int for new id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Returns the date of the visit
     * @return String for the date
     */
    public String getDate() {
        return date;
    }

    /**
     * Changes the date of the visit
     * @param date String for the new date
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     * Returns the time of the visit
     * @return String for the time
     */
    public String getTime() {
        return time;
    }

    /**
     * Changes the time of the visit
     * @param time String for the new time.
     */
    public void setTime(String time) {
        this.time = time;
    }

    /**
     * Returns the animal ID that is linked to this visit
     * @return int for the animal ID
     */
    public int getAnimalID() {
        return animalID;
    }

    /**
     * Changes the ID for what animal this visit is linked to
     * @param animalID int for the animal ID
     */
    public void setAnimalID(int animalID) {
        this.animalID = animalID;
    }

    /**
     * Returns the details of the visit
     * @return String for the details
     */
    public String getDetails() {
        return details;
    }

    /**
     * Changes details of the visit
     * @param details String of the new details
     */
    public void setDetails(String details) {
        this.details = details;
    }

    /**
     * Adds details to the end like once the vet/tech
     * see's the animal add their notes in.
     * @param details
     */
    public void addDetails(String details) {
        this.details += "\n" + details;
    }

    /**
     * Used on the animal itself so we don't need to see the animalID
     * as this get's printed on it.
     * @return of visit information
     */
    public String animalVisitString() {
        return " Time: " + time + "\nDetails:\n" + details;
    }

    /**
     * String output of the object
     * @return String version of object
     */
    public String toString() {
        return "ID: " + id + " - Date: " + date + " Time: " + time + " Animal ID: " + animalID + "\nDetails:\n" + details;
    }

    /**
     * This breaks the details down by new line and puts '~' in between to keep everything
     * on one line for printout back to a file.
     * @return String for the details printed out on one line
     */
    public String getDetailsFileOut() {
        String deets = "";
        for (String d : details.split("\n")) {
            deets += d + "~";
        }
        deets = deets.substring(0, deets.length() - 1); // remove the last ~
        return deets;
    }
}
