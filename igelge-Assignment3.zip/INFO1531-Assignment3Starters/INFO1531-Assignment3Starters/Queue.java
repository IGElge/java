/*
NAME: Isabella Elge
DATE:09/22/2025
CLASS: INFO 1531
ASSIGNMENT: Assignment 3 - Pet Schedule
RESOURCES: I utilized the book and the lecture for this assignment

PURPOSE: This is a custom Queue for the file so the rest of the .java files run as inteneded by being processed through
this custom queue.
 */
import java.util.LinkedList;
import java.util.List;

//The Queue should be defined as a generic in the public class header.
public class Queue<E> {
    //Define a private instance variable for a LinkedList object that can store the elements of the queue.
    private LinkedList<E> list = new LinkedList<>();

    //enqueue(E element) - adds an element to the linked list
    public void enqueue(E element) {
        list.add(element);
    }

    //dequeue() - returns the element at the top of the queue
    public E dequeue() {
        return list.remove();
    }

    //peek() - returns the element at the top of the queue but does not remove it.
    public E peek (){
        return list.peek();
    }

    //size() - returns the number of elements in the queue
    public int size() {
        return list.size();
    }

    //isEmpty() - returns true if no items are in the list, false otherwise
    public boolean isEmpty() {
        return list.isEmpty();
    }

    //addAll(List<E> list) - takes a generic list and adds all the elements into the queue
    public void addAll(List<E>inputlist){
        list.addAll(inputlist);
    }

    //toList() - returns a List<E> object that should just return the "list" variable that is our Queue.
    public List<E> toList(){
        return list;
    }
}
