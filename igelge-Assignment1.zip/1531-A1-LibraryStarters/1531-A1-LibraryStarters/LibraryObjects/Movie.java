package App.LibraryObjects;
import java.util.ArrayList;
import App.LibraryBlueprints.Item;
import App.LibraryBlueprints.CheckOutLog;
import App.LibraryBlueprints.*;
/**
 * This is the object that represents a Movie in the library system.
 *
 * @author Lucas Hartman
 * @version 1.0.0
 */
public class Movie extends Item {
    private MovieRating rating; // G, PG, PG-13, etc.
    private String cast; // main people in movie
    private String director;
    private String producer; // could be more than one list?
    private int length; // in minutes

    /**
     * Main constructor that is used to create a new Movie in the system.
     * @param id String for the object ID
     * @param title String for the movie title
     * @param publisher String for the publisher of the movie
     * @param copyright int for the year was released
     * @param rating String for the rating of the movie, G, PG, PG-13, R
     * @param cast String for the main cast in the movie
     * @param director String for the director(s) of the movie
     * @param producer String for the producer(s) of the movie
     * @param length int for the length of them movie in minutes
     */
    public Movie(String id, String title, String publisher, int copyright, MovieRating rating, String cast,
                 String director, String producer, int length) {
        super(id, title, publisher, copyright,ItemType.MOVIE);
        this.rating = rating;
        this.cast = cast;
        this.director = director;
        this.producer = producer;
        this.length = length;
    }

    /**
     * This is the constructor used when migrating object to the system and a CheckOutLog history and whether it is
     * currently checked out is sent. Typically used if the item already exists in another system and sent over
     * to this system.
     *
     * @param id String for the object ID
     * @param title String for the movie title
     * @param publisher String for the publisher of the movie
     * @param copyright int for the year was released
     * @param checkedOut boolean value for if the object is currently checked out
     * @param log ArrayList of CheckOutLog objects giving the history of checkout of this Movie
     * @param rating String for the rating of the movie, G, PG, PG-13, R
     * @param cast String for the main cast in the movie
     * @param director String for the director(s) of the movie
     * @param producer String for the producer(s) of the movie
     * @param length int for the length of them movie in minutes
     */
    public Movie(String id, String title, String publisher, int copyright, boolean checkedOut,
                 ArrayList<CheckOutLog> log, MovieRating rating, String cast, String director, String producer, int length) {
        super(id, title, publisher, copyright,ItemType.MOVIE, checkedOut, log);
        this.rating = rating;
        this.cast = cast;
        this.director = director;
        this.producer = producer;
        this.length = length;
    }

    /**
     * Sends the rating of the movie back
     * @return String for the rating
     */
    public MovieRating getRating() {
        return rating;
    }

    /**
     * Updates the rating of the movie
     * @param rating String for the new rating.
     */
    public void setRating(MovieRating rating) {
        this.rating = rating;
    }

    /**
     * Sends the cast of the movie back
     * @return String for the cast
     */
    public String getCast() {
        return cast;
    }

    /**
     * Updates the cast of the movie
     * @param cast String for the cast
     */
    public void setCast(String cast) {
        this.cast = cast;
    }

    /**
     * Sends back the director(s) of the movie
     * @return String for the director(s)
     */
    public String getDirector() {
        return director;
    }

    /**
     * Updates the director(s) of the movie
     * @param director String for the new directors
     */
    public void setDirector(String director) {
        this.director = director;
    }

    /**
     * Sends back the producer(s) of the movie
     * @return String for the producer(s)
     */
    public String getProducer() {
        return producer;
    }

    /**
     * Updates the producer(s) of the movie
     * @param producer String for the producer(s)
     */
    public void setProducer(String producer) {
        this.producer = producer;
    }

    /**
     * Sends back the length of the movie in minutes
     * @return int for length of the movie in minutes
     */
    public int getLength() {
        return length;
    }

    /**
     * Updates the length of the movie
     * @param length int for the new length in minutes
     */
    public void setLength(int length) {
        this.length = length;
    }

    /**
     * Method to print out the movie object.
     * @return String for the printout
     */
    @Override
    public String toString() {
        return super.toString()
                + "\nRating: " + rating
                + "\nCast: " + cast
                + "\nDirector: " + director
                + "\nProducers: " + producer
                + "\nLength: " + length + " minutes";
    }


}
