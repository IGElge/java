/**
 * NAME: Isabella Elge
 * DATE: September 9th, 2025
 * CLASS: INFO 1531
 * ASSIGNMENT: Assignment 1 - Interface, Enum & Javadocs with Library System
 * RESOURCES: I used the book and video lectures to help me with this assignment.
 *
 * PURPOSE: This creates the magazines for the library system by outlining parameters and calling the ItemType enumerator
 */
/**
 *Assigns this file to the LibraryObjects package
 */
package App.LibraryObjects;
/**
 * imports various items needed to run this code
 */
import java.util.ArrayList;
import App.LibraryBlueprints.Item;
import App.LibraryBlueprints.CheckOutLog;
import App.LibraryBlueprints.ItemType;
/**
 *Magazine class for library, and sets up the separate variables
*/
 public class Magazine extends Item {
    private String issue;
    private String category;
    private String issn;

    /**
     * Main constructor that is used to create a new Magazine in the system.
     * @param id String for the object ID
     * @param title String for the movie title
     * @param publisher String for the publisher of the movie
     * @param copyright int for the year was released
     * @param issue String for the issue of the magazine
     * @param category String for the category of the magazine
     * @param issn String for the issn of the magazine
     */
    public Magazine(String id, String title, String publisher, int copyright,
                    String issue, String category, String issn) {
        super(id, title, publisher, copyright,ItemType.MAGAZINE);
        this.issue = issue;
        this.category = category;
        this.issn = issn;
    }

    /**
     * This is the constructor used when migrating object to the system and a CheckOutLog history and whether it is
     * currently checked out is sent. Typically used if the item already exists in another system and sent over
     * to this system.
     *
     * @param id String for the object ID
     * @param title String for the magazine title
     * @param publisher String for the publisher of the magazine
     * @param copyright int for the year was released
     * @param checkedOut boolean value for if the object is currently checked out
     * @param log ArrayList of CheckOutLog objects giving the history of checkout of this magazine
     * @param issue String for the issue of the magazine
     * @param category String for the category of the magazine
     * @param issn String for the issn of the magazine
     */
    public Magazine(String id, String title, String publisher, int copyright, boolean checkedOut,
                    ArrayList<CheckOutLog> log, String issue, String category, String issn) {
        super(id, title, publisher, copyright,ItemType.MAGAZINE, checkedOut, log);
        this.issue = issue;
        this.category = category;
        this.issn = issn;
    }

    /**
     * Sends back the issue of the magazine
     * @return issue in a string of numbers
     */    public String getIssue() {
        return issue;
    }

    /**
     * Updates the issue of the magazine
     * @param issue string for the new issue in a string of numbers
     */
    public void setIssue(String issue) {
        this.issue = issue;
    }
    /**
     * Sends back the category of the magazine in a text string
     * @return category in a text string
     */
    public String getCategory() {
        return category;
    }

    /**
     * Updates the catagory of the magazine
     * @param category string for the new category in a text string
     */
    public void setCategory(String category) {
        this.category = category;
    }

    /**
     * Sends back the issn of the magazine in a string of numbers
     * @return issn in a string of numbers
     */
    public String getIssn() {
        return issn;
    }

    /**
     * Updates the issn of the magazine
     * @param issn string for the new issn in a string of numbers
     */
    public void setIssn(String issn) {
        this.issn = issn;
    }

    /**
     * Method to print out the magazine object.
     * @return String for the printout
     */
    @Override
    public String toString() {
        return super.toString()
                + "\nIssue: " + issue
                + "\nCategory: " + category
                + "\nISSN: " + issn;
    }
}
