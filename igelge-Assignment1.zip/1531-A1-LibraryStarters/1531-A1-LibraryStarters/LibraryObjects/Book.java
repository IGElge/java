package App.LibraryObjects;
import App.LibraryBlueprints.CheckOutLog;
import App.LibraryBlueprints.Item;
import App.LibraryBlueprints.ItemType;
import java.util.ArrayList;

/**
 * This is the class that represents a book in the library system.
 *
 * @author Lucas Hartman
 * @version 1.0.0
 *
 */
public class Book extends Item{
    private String author;
    private String isbn;
    private String genre; // fiction, non-fiction, etc.
    private String subject;  // short description of what the book covers
    private int pageCount;

    /**
     * Main constructor that creates a brand new book in the system.
     *
     * @param id String for the ID of the book
     * @param title String for the title of the book
     * @param publisher String for the publisher of the book
     * @param copyright int for the copyright of the book
     * @param isbn String for the isbn of the book
     * @param genre String for the genre of the book
     * @param subject String for the subject - short description of the book
     * @param pageCount int for the length of the book as pages
     */
    public Book(String id, String title, String publisher, int copyright, String author,
                String isbn, String genre, String subject, int pageCount) {
        super(id, title, publisher, copyright, ItemType.BOOK);
        this.author = author;
        this.isbn = isbn;
        this.genre = genre;
        this.subject = subject;
        this.pageCount = pageCount;
    }

    /**
     * Constructor used to migrate books to this system.
     *
     * @param id String for the ID of the book
     * @param title String for the title of the book
     * @param publisher String for the publisher of the book
     * @param copyright int for the copyright of the book
     * @param checkedOut boolean value for if the book is currently checked out or available
     * @param log ArrayList of CheckOutLog objects as a checkout history of the book
     * @param isbn String for the isbn of the book
     * @param genre String for the genre of the book
     * @param subject String for the subject - short description of the book
     * @param pageCount int for the length of the book as pages
     */
    public Book(String id, String title, String publisher, String author, int copyright, boolean checkedOut,
                ArrayList<CheckOutLog> log, String isbn, String genre, String subject, int pageCount) {
        super(id, title, publisher, copyright,ItemType.BOOK, checkedOut, log);
        this.author = author;
        this.isbn = isbn;
        this.genre = genre;
        this.subject = subject;
        this.pageCount = pageCount;
    }

    /**
     * Sends back the author
     * @return String of the author
     */
    public String getAuthor() {
        return author;
    }

    /**
     * Updates the author of the book
     * @param author String for the new author
     */
    public void setAuthor(String author) {
        this.author = author;
    }

    /**
     * Sends back the ISBN of the book
     * @return String of the ISBN
     */
    public String getIsbn() {
        return isbn;
    }

    /**
     * Updates the ISBN of the book
     * @param isbn String for the new ISBN
     */
    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    /**
     * Sends back the genre of the book
     * @return String for the genre
     */
    public String getGenre() {
        return genre;
    }

    /**
     * Updates the genre of the book
     * @param genre String for the new genre
     */
    public void setGenre(String genre) {
        this.genre = genre;
    }

    /**
     * Sends back the subject/short description of the book
     * @return String for the subject
     */
    public String getSubject() {
        return subject;
    }

    /**
     * Updates the subject/description of the book
     * @param subject String for the new subject
     */
    public void setSubject(String subject) {
        this.subject = subject;
    }

    /**
     * Sends back the number of pages of the book
     * @return int page count
     */
    public int getPageCount() {
        return pageCount;
    }

    /**
     * Updates the number of pages for the book
     * @param pageCount int for the new page count
     */
    public void setPageCount(int pageCount) {
        this.pageCount = pageCount;
    }

    /**
     * String version of the book
     * @return String of the book values
     */
    @Override
    public String toString() {
        return super.toString()
                + "\nGenre: " + genre
                + "\nSubject: " + subject
                + "\nISBN: " + isbn;
    }
}
