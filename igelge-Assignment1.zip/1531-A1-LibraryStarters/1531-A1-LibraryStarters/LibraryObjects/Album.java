package App.LibraryObjects;
import java.util.ArrayList;
import App.LibraryBlueprints.Item;
import App.LibraryBlueprints.CheckOutLog;
import App.LibraryBlueprints.ItemType;
/**
 * This is the class to hold a musical album in the libary system
 *
 * @author Lucas Hartman
 * @version 1.0.0
 */
public class Album extends Item{
    private String artist;
    private String genre;
    private String[] tracks; // array of the track names.
    private int length; // in minutes for total album

    /**
     * This is the main constructor to create a brand new album into the system.
     * @param id String for the id of the album in the library system
     * @param title String for the title of the album
     * @param publisher String for the publisher of the album
     * @param copyright int for the copyright year
     * @param artist String for the name of the artist of the album
     * @param genre String for the genre of the album
     * @param tracks String[] for the track list of the album
     * @param length int for the length of the album in minutes
     */
    public Album(String id, String title, String publisher, int copyright, String artist,
                 String genre, String[] tracks, int length) {
        super(id, title, publisher, copyright, ItemType.ALBUM);
        this.artist = artist;
        this.genre = genre;
        this.tracks = tracks;
        this.length = length;
    }

    /**
     * This constructor is used for migrating to the system as it as a list of check out data and if it is currently
     * checked out or available.
     *
     * @param id String for the id of the album in the library system
     * @param title String for the title of the album
     * @param publisher String for the publisher of the album
     * @param copyright int for the copyright year
     * @param checkedOut boolean value for if it is currently checked out or available
     * @param log ArrayList of CheckOutLog for the check out history
     * @param artist String for the name of the artist of the album
     * @param genre String for the genre of the album
     * @param tracks String[] for the track list of the album
     * @param length int for the length of the album in minutes
     */
    public Album(String id, String title, String publisher, int copyright, boolean checkedOut,
                 ArrayList<CheckOutLog> log, String artist, String genre, String[] tracks, int length) {
        super(id, title, publisher, copyright, ItemType.ALBUM, checkedOut, log);
        this.artist = artist;
        this.genre = genre;
        this.tracks = tracks;
        this.length = length;
    }

    /**
     * Sends back the artist of the album
     * @return String for the artist
     */
    public String getArtist() {
        return artist;
    }

    /**
     * Updates the artist of the album
     * @param artist String for the new artist
     */
    public void setArtist(String artist) {
        this.artist = artist;
    }

    /**
     * Sends back the genre of the album
     * @return String for the genre
     */
    public String getGenre() {
        return genre;
    }

    /**
     * Updates the genre of the album
     * @param genre String for the new genre
     */
    public void setGenre(String genre) {
        this.genre = genre;
    }

    /**
     * Sends back tracks as an array
     * @return String[] of the tracks
     */
    public String[] getTracks() {
        return tracks;
    }

    /**
     * Updates the track of the album
     * @param tracks String[] of the new tracks
     */
    public void setTracks(String[] tracks) {
        this.tracks = tracks;
    }

    /**
     * Sends back the length of the album in minutes
     * @return int of the length in minutes
     */
    public int getLength() {
        return length;
    }

    /**
     * Updates the length of the album
     * @param length int of the new length in minutes
     */
    public void setLength(int length) {
        this.length = length;
    }

    /**
     * Creates a string to printout of all the track names
     * @return String of the track names
     */
    public String trackListToString() {
        String list = "";
        for (String t : tracks) {
            list += t + "\n";
        }
        return list;
    }

    /**
     * Used to print out the object information
     * @return String value of the Album
     */
    @Override
    public String toString() {
        int hours = length / 60;
        int minutes = length % 60;
        String minuteSecLength = minutes + "m";
        if (hours > 0) {
            minuteSecLength = hours + "h " + minuteSecLength;
        }

        return super.toString() + "\nArtist: " + artist + "\nGenre: " + genre + "\nTotal Length: " + minuteSecLength;
    }

    @Override
    public String logDataString() {
        return "Album: " + getTitle() + " by " + artist + " (" + getId() + ")";
    }

}
