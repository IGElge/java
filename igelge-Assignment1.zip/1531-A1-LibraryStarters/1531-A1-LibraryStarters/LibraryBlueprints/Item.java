package App.LibraryBlueprints;

import java.util.ArrayList;
import App.LibraryBlueprints.CheckOutLog;
import App.LibraryBlueprints.Member;
import App.LibraryBlueprints.ItemType;
import App.LibraryBlueprints.LogObject;



/**
 * This is the main abstract object that holds the base information for items at the library.
 *
 * @author Lucas Hartman
 * @version 1.0.0
 */
public abstract class Item implements LogObject {
    private String id; // this is used for checking out and is unique to each item, even with duplicates
    private String title;
    private String publisher;
    private int copyright;
    private ItemType type; // Newspaper, Book, Magazine, Album, Movie, etc.
    private boolean checkedOut; // true if checked out, false if available
    private ArrayList<CheckOutLog> checkOutLog; // list of all check outs

    /**
     * This is the constructor used for creating new objects. Takes on all inputs except
     * the checkedOut value which is always set to false as it is new.
     * @param id String for the ID of the object, this is unique and used when checking out
     * @param title String for the name/title of the item
     * @param publisher String for the publisher of the item
     * @param copyright int for the copyright year
     * @param type String for the type of item in the Library that it is.
     */
    public Item(String id, String title, String publisher, int copyright, ItemType type) {
        this.id = id;
        this.title = title;
        this.publisher = publisher;
        this.copyright = copyright;
        this.type = type;
        this.checkedOut = false;
        checkOutLog = new ArrayList<>();
    }

    /**
     * Constructor used for adding objects or transferring to a new system.
     * You can specifically set if the library object is checked out or not.
     * @param id String for the ID of the object, this is unique and used when checking out
     * @param title String for the name/title of the item
     * @param publisher String for the publisher of the item
     * @param copyright int for the copyright
     * @param type String for the type of item in the Library that it is.
     * @param checkedOut boolean that will be true if checked out, false if checked in
     * @param log ArrayList<CheckOutLog> for the checkout history
     */
    public Item(String id, String title, String publisher, int copyright, ItemType type,
                boolean checkedOut, ArrayList<CheckOutLog> log) {
        this.id = id;
        this.title = title;
        this.publisher = publisher;
        this.copyright = copyright;
        this.type = type;
        this.checkedOut = checkedOut;
        checkOutLog = log;
    }

    /** Returns back the id of the object. */
    public String getId() { return id; }

    /** Updates the id of the item */
    public void setId(String id) { this.id = id; }

    /** Returns back the title of the item */
    public String getTitle() { return title; }

    /** Updates the title of the item */
    public void setTitle(String title) { this.title = title; }

    /** Returns back the publisher of the item */
    public String getPublisher() { return publisher; }

    /** Updates the publisher of item */
    public void setPublisher(String publisher) { this.publisher = publisher; }

    /** Returns the copyright of the item */
    public int getCopyright() { return copyright; }

    /** Updates the copyright of the item */
    public void setCopyright(int copyright) { this.copyright = copyright; }

    /** Returns the type of the item */
    public ItemType getType() { return type; }

    /** Updates the type of the item */
    public void setType(ItemType type) { this.type = type; }

    /** Checks whether the item is checked out or not */
    public boolean isCheckedOut() { return checkedOut; }

    /**
     * Sets checkedOut to false meaning an item is returned and available.
     * Accesses the last item in the checkout log and adds in a checkin date.
     * Also calls the checkout log data in a Member and completes the check-in on their side.
     * @param date String of the date checked back in
     */
    public void checkIn(String date) {
        checkedOut = false;
        CheckOutLog lastEntry = checkOutLog.get(checkOutLog.size() - 1);
        lastEntry.setCheckInDate(date);

        ((Member) lastEntry.getLogData()).completeMemberCheckIn(this, date);
    }

    /**
     * Sets checkedOut to true meaning an item is checked out.
     * Also creates an entry in the checkout log for the date and who checked it out.
     * @param date String of the checkout date of the item
     * @param member Member object of the library checking it out
     */
    public void checkOut(String date, Member member) {
        checkedOut = true;
        checkOutLog.add(new CheckOutLog(date, member));
        member.addToMemberLog(new CheckOutLog(date, this));
    }

    /** Returns a String of the checkout history of the item */
    public String checkOutHistory() {
        String list = "";
        for (CheckOutLog log : checkOutLog) {
            list += log.toString() + "\n";
        }
        return list;
    }

    /**
     * Compares this item to another via the ID of the items.
     * @param obj2 Object for the other item
     * @return true if the IDs match, false otherwise
     */
    @Override
    public boolean equals(Object obj2) {
        if (obj2 instanceof Item) {
            Item i2 = (Item) obj2;
            return id.equals(i2.getId());
        }
        return false;
    }

    /**
     * Prints a tostring version of the output
     * @return a list of title, publisher, type, and availability
     */
    @Override
    public String toString() {
        String available = isCheckedOut() ? "No" : "Yes";
        return "Title: " + title +
                "\nPublisher: " + publisher +
                "\nType: " + type.toString() +
                "\nAvailable: " + available;
    }

    /**
     * Adds the type, title, and library id together
     * @return the type, title, and library id for the users when checked out
     */
    @Override
    public String logDataString() {
        return "Type: " + type.toString() + " - Title: " + title + " - Library ID: " + id;
    }
}
