/**
 * NAME: Isabella Elge
 * DATE: September 9th, 2025
 * CLASS: INFO 1531
 * ASSIGNMENT: Assignment 1 - Interface, Enum & Javadocs with Library System
 * RESOURCES: I used the book and video lectures to help me with this assignment.
 *
 * PURPOSE: This creates the movie rating enum for the library system
 */
/**
*Assigns this file to the LibraryBlueprints package
 */
package App.LibraryBlueprints;

/**
 * declares a public enumerator named MovieRating with multiple different items inside
 */
public enum MovieRating {
    /**
     *The G constant for MovieRating
     */
    G,
    /**
     *The PG constant for MovieRating
     */
    PG,
    /**
     *The PG13 constant for MovieRating
     */
    PG13,
    /**
     *The R constant for MovieRating
     */
    R;

    /**
     *overrides a tostring method and refers to a specific case below
     */
    @Override
    public String toString() {
        return switch(this) {
            case G -> "G";
            case PG -> "PG";
            case PG13 -> "PG-13";
            case R -> "R";
        };
    }

}