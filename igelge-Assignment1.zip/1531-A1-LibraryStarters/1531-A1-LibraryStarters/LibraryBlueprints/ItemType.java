/**
 * NAME: Isabella Elge
 * DATE: September 9th, 2025
 * CLASS: INFO 1531
 * ASSIGNMENT: Assignment 1 - Interface, Enum & Javadocs with Library System
 * RESOURCES: I used the book and video lectures to help me with this assignment.
 *
 * PURPOSE: This creates the ItemType enum for the library system
 */
/**
* Assigns this file to the LibraryBlueprints package
*/
package App.LibraryBlueprints;

/**
*declares a public enumerator named ItemType with multiple different items inside
*/
public enum ItemType {
    /**
    *The Book constant for ItemType
     */
    BOOK,
    /**
     *The Movie constant for ItemType
     */
    MOVIE,
    /**
     *The Album constant for ItemType
     */
    ALBUM,
    /**
     *The Magazine constant for ItemType
     */
    MAGAZINE,;
    /**
     * overrides a tostring method and refers to a specific case below
     */
    @Override
    public String toString() {
        String s = switch (this.ordinal()) {
            case 0 -> "Book";
            case 1 -> "Movie";
            case 2 -> "Album";
            case 3 -> "Magazine";
            default -> "";
        };
        return s;
    }
}


