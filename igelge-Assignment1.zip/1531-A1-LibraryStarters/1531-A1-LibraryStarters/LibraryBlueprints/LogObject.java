/**
 * NAME: Isabella Elge
 * DATE: September 9th, 2025
 * CLASS: INFO 1531
 * ASSIGNMENT: Assignment 1 - Interface, Enum & Javadocs with Library System
 * RESOURCES: I used the book and video lectures to help me with this assignment.
 *
 * PURPOSE: Defines logging behavior for data objects
 */
package App.LibraryBlueprints;

/**
 * Creates a public interface named LogObject
 */
public interface LogObject {
    /**
     *String representation for logging purposes
     * @return a string representation of an object for logging purposes
     */
    String logDataString();
}