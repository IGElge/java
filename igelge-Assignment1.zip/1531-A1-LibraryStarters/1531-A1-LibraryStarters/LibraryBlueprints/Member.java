package App.LibraryBlueprints;

import java.util.ArrayList;
import App.LibraryBlueprints.LogObject;
import App.LibraryBlueprints.Item;
import App.LibraryBlueprints.CheckOutLog;


/**
 * This is the class that represents members in the library book system
 *
 * @author Lucas Hartman
 * @version 1.0.0
 */
public class Member implements LogObject {
    private String id;
    private String name;
    private ArrayList<CheckOutLog> memberLog; // used to track what books they have checked out.

    /**
     * Main constructor to create the member
     * @param id
     * @param name
     */
    public Member(String id, String name) {
        this.id = id;
        this.name = name;
        memberLog = new ArrayList<>();
    }

    /**
     * Sends back the ID of the member
     * @return String for the ID
     */
    public String getId() {
        return id;
    }

    /**
     * Updates the ID of the member
     * @param id String for the new ID
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Sends back the name of the member
     * @return String for the name
     */
    public String getName() {
        return name;
    }

    /**
     * Updates the name of the member
     * @param name String for the new name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Adds a checkout log when the member checks out an item
     * @param log CheckOutLog entry that has dates and reference to item checked out/in
     */
    public void addToMemberLog(CheckOutLog log) {
        memberLog.add(log);
    }

    /**
     * Method will complete the check in of an item when a member checks in the book
     * @param item Item that is 'checked in' to reference in the member log
     * @param date String for the date of check in.
     */
    public void completeMemberCheckIn(Item item, String date) {
        for (CheckOutLog log : memberLog) {
            if (log.isNotComplete()) { // check if log is not complete meaning not check in date
                Item logItem = (Item)log.getLogData();
                if (item.equals(logItem)) { // check if this is the item in list as member can have multiple items checked out
                    log.setCheckInDate(date);  // if item matches set check in date
                }
            }

        }
    }

    /**
     * Text output of the member
     * @return String of the member values
     */
    public String toString() {
        return "Member ID: " + id + "\nName: " + name;
    }

    /**
     * Used to compare member objects. Helps to check whether we have duplicates
     * @param obj2 The other member
     * @return True of the ID values match, false if not
     */
    public boolean equals(Object obj2) {
        if (obj2 instanceof Member) {
            Member m2 = (Member) obj2;
            return id.equals(m2.getId());
        }
        return false;
    }

    /**
     * String version of the members
     * @return a formatted version of the output
     */
    @Override
    public String logDataString(){
        return "Name: " + name + " - ID: " + id;
    }

}