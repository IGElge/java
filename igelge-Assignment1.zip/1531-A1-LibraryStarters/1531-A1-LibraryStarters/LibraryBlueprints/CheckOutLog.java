package App.LibraryBlueprints;
import App.LibraryBlueprints.LogObject;
/**
 * This object is used to store when an item gets checkout and in.
 *
 * @author Lucas Hartman
 * @version 1.0.0
 */
public class CheckOutLog {
    private String checkOutDate;
    private String checkInDate;
    private LogObject logData;

    /**
     * Main constructor that creates a log when an item is checked out. Check in is blank to start.
     *
     * @param checkOutDate String for the checkout date
     * @param logData LogObject of the item or member that will be connected. Interface for using this universally.
     */
    public CheckOutLog(String checkOutDate, LogObject logData) {
        this.checkOutDate = checkOutDate;
        checkInDate = ""; // checkInDate blank as member hasn't returned
        this.logData = logData;
    }

    /**
     * Constructor used to create logs that have already been done. Migration constructor.
     * @param checkOutDate String of the check out date
     * @param checkInDate String of the check in date
     * @param logData LogObject of the item or member that will be connected. Interface for using this universally.
     */
    public CheckOutLog(String checkOutDate, String checkInDate, LogObject logData) {
        this.checkOutDate = checkOutDate;
        this.checkInDate = checkInDate;
        this.logData = logData;
    }

    /**
     * Sends back the check out date
     * @return String of date
     */
    public String getCheckOutDate() {
        return checkOutDate;
    }

    /**
     * Updates the check out date
     * @param checkOutDate String of the new check out date
     */
    public void setCheckOutDate(String checkOutDate) {
        this.checkOutDate = checkOutDate;
    }

    /**
     * Sends back the check in date
     * @return String of date
     */
    public String getCheckInDate() {
        return checkInDate;
    }

    /**
     * Updates the check in date
     * @param checkInDate String for new check in date
     */
    public void setCheckInDate(String checkInDate) {
        this.checkInDate = checkInDate;
    }

    /**
     * Sends back the object (item or member) that is connected to this log entry
     * @return LogObject of an item or member
     */
    public LogObject getLogData() {
        return logData;
    }

    /**
     * Updates the log object(item or memeber) that is connected to this log entry
     * @param logData LogObject of the item or memeber for this entry
     */
    public void setLogData(LogObject logData) {
        this.logData = logData;
    }

    /**
     * Checks to see if data is complete
     * @return an incomplete form
     */
    public boolean isNotComplete() {
        return checkInDate.equals("");
    }

    /**
     * Text printout of the object
     * @return String of the log values
     */
    public String toString() {
        return "Checked Out: " + checkOutDate + "\nChecked In: " + checkInDate + "\nData: " + logData;
    }
}
