package App.App;

import App.LibraryObjects.*;
import App.LibraryBlueprints.*;

import java.util.ArrayList;

/**
 *
 * @author Lucas Hartman
 * @version 1.0.0
 * 
 * This file will run through and make sure you have implemented 
 * the Enumerations and Packages correct for Assignment 1.
 *
 *    YOU DO NOT NEED TO MODIFY ANY OF THIS CODE, JUST RUN THIS FILE TO COMPARE OUTPUTS
 */



public class A1LibraryChecker {
    /**
     * Main method to test out the A10 items.
     * @param args String array of console inputs
     */
    public static void main(String[] args)
    {

        Member[] libraryMembers = new Member[3];
        libraryMembers[0] = new Member("123456", "Steve Rodgers");
        libraryMembers[1] = new Member("345678", "Tony Stark");
        libraryMembers[2] = new Member("567891", "Bruce Banner");

        Item[] libraryItems = new Item[12];
        libraryItems[0] = new Album("837524", "Getting Away with Murder", "Universal Music Operation Limited", 2007, "Papa Roach",
                "Alternative Rock", new String[]{"Blood(Empty Promises", "Not Listening", "Stop Looking Start Seeing", "Take Me",
                "Getting Away with Murder", "Be Free", "Done with You", "Scars", "Sometimes", "Blanket of Fear",
                "Tyranny of Normality", "Do or Die"}, 38);
        libraryItems[1] = new Book("843248", "The PROX Transmission", "The Starset Society", 2016, "The Starset Society",
                "978-0997261806", "Science Fiction", "Advance technology, Space travel", 260);
        libraryItems[2] = new Book("601710", "The Fellowship of the Ring", "George Allen & Unwin", 1954, "J. R. R. Tolkien",
                "978-0261103573", "Fantasy", "Characters must face dark forces to save middle earth.", 423);
        libraryItems[3] = new Album("542367", "Country Grammar", "Univeral", 2000, "Nelly", "Hip Hop", new String[]{"Intro", "St. Louie",
        "Greed, Hate, Envy", "Country Grammar", "Steal the Show", "Interlude", "Ride wit Me", "E.I.", "Thicky Thick Girl", "For My", "Utha Side",
        "Tho Dem Wrappas", "Wrap Sumden", "Batter Up", "Never Let 'Em C U Sweat", "Luven Me", "Outro"}, 67);
        libraryItems[4] = new Album("699180", "Abbey Road", "Apple", 1969, "The Beatles", "Rock", new String[]{"Come Together", "Something",
        "Maxwell's Silver Hammer", "Oh! Darling", "Octopus's Garden", "I Want You(She's So Heavy", "Here Comes the Sun", "Because",
        "You Never Give Me Your Money", "Sun King", "Mean Mr. Mustard", "Polythene Pam", "She Came In Through the Bathroom Windows",
        "Golden Slumbers", "Carry That Weight", "The End", "Her Majesty"}, 47);
        libraryItems[5] = new Album("577865", "Believe", "Warner Bros", 1998, "Cher", "Euro disco", new String[]{"Believe",
                "The Power", "Runaway", "All or Nothing", "Strong Enough", "Dov'è l'amore", "Takin' Back My Heart", "Taxi Taxi",
                "Love is the Groove", "We All Sleep Alone"}, 100);
        libraryItems[6] = new Movie("716929", "Star Wars: Episode IV - A New Hope", "Lucasfilm Ltd.", 1977, MovieRating.PG,
                "Mark Hamill, Harrison Ford, Carrie Fisher, Petere Cushing, Alec Guinness", "George Lucas", "Gary Kurtz", 121);
        libraryItems[7] = new Movie("660409", "The Terminator", "Orion Pictures", 1984, MovieRating.R,
                "Arnold Schwarzenegger, Michael Biehn, Linda Hamilton, Paul Winfield", "James Cameron", "Gale Anne Hurd", 107);
        libraryItems[8] = new Movie("801861", "The Waterboy", "Touchstone Pictures", 1998, MovieRating.PG13,
                "Adam Sandler, Kathy Bates, Fairuza Balk, Jerry Reed, Henry Winkler", "Frank Coraci", "Jack Giarraputo & Robert Simonds", 90 );
        libraryItems[9] = new Magazine("523643", "Bon Appetit", "Conde Nast Publications", 2024, "February", "Food", "0006-6990");
        libraryItems[10] = new Magazine("470972", "People", "Meredith Corporation", 2023, "9 Volume 99", "Entertainment", "0093-7673");
        libraryItems[11] = new Book("854192", "To Kill a Mockingbird", "J.B. Lippincott & Co.", 1960, "Harper Lee",
                "978-0397001514", "Southern Gothic", "Southern life, racial injustice, courage and compassion", 281);

        // add members and library into an arraylist together, checking the Interface
        ArrayList<LogObject> allObjects = new ArrayList<>();
        for (Member m : libraryMembers) {
            allObjects.add(m);
        }
        for (Item i : libraryItems) {
            allObjects.add(i);
        }


        // use ItemType enum to filter and print only matching types
        System.out.println("**** Movies ****");
        for (Item i : libraryItems) {
            if (i.getType() == ItemType.MOVIE) {
                System.out.println(i + "\n");
            }
        }

        // use ItemType enum to filter and print only matching types
        System.out.println("\n**** Magazines ****");
        for (Item i : libraryItems) {
            if (i.getType() == ItemType.MAGAZINE) {
                System.out.println(i + "\n");
            }
        }

        // use ItemType enum to filter and print only matching types
        System.out.println("\n**** Music Albums ****");
        for (Item i : libraryItems) {
            if (i.getType() == ItemType.ALBUM) {
                System.out.println(i + "\n");
            }
        }

        // use ItemType enum to filter and print only matching types
        System.out.println("\n**** Books ****");
        for (Item i : libraryItems) {
            if (i.getType() == ItemType.BOOK) {
                System.out.println(i + "\n");
            }
        }

        // check if logDataString() method implemented
        System.out.println("\n\n**** Check for Interface Method ****");
        for (LogObject obj : allObjects) {
            System.out.println(obj.logDataString());
        }
        

    }
}
