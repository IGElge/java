/**
 * Course object to hold the information on a class.
 */
public class Course {
    private int id;
    private Department dept;
    private String number;
    private String title;
    private String instructor;
    private String days;
    private String startTime;
    private String endTime;
    private String location;

    /**
     * Main constructor
     * @param id int for the ID of the course
     * @param dept Department for department of the class
     * @param number String for the course number
     * @param title String for the course title
     * @param instructor String for the instructor of the course
     * @param days String for the days of the course
     * @param startTime String for the start time of the course
     * @param endTime String for the end time of hte course
     * @param location String for the location of the class
     */
    public Course(int id, Department dept, String number, String title, String instructor, String days, String startTime, String endTime, String location) {
        this.id = id;
        this.dept = dept;
        this.number = number;
        this.title = title;
        this.instructor = instructor;
        this.days = days;
        this.startTime = startTime;
        this.endTime = endTime;
        this.location = location;
    }

    /**
     * Gets the course ID
     * @return int of the ID
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the id of the course
     * @param id int for the new course
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Gets the department of the course
     * @return Department of the course
     */
    public Department getDept() {
        return dept;
    }

    /**
     * sets the department of the course
     * @param dept Department to update
     */
    public void setDept(Department dept) {
        this.dept = dept;
    }

    /**
     * Gets the course number
     * @return String of the course number
     */
    public String getNumber() {
        return number;
    }

    /**
     * Sets the course number
     * @param number String of the new course
     */
    public void setNumber(String number) {
        this.number = number;
    }

    /**
     * Gets the title of the course
     * @return String of the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the title of the course
     * @param title String of the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Gets the instructor of the course
     * @return String of the instructor
     */
    public String getInstructor() {
        return instructor;
    }

    /**
     * Sets the instructor of the course
     * @param instructor String of the instructor to set
     */
    public void setInstructor(String instructor) {
        this.instructor = instructor;
    }

    /**
     * Gets the day of the week the course is taught
     * @return String for the days
     */
    public String getDays() {
        return days;
    }

    /**
     * Sets the days of the week the course is taught
     * @param days String for the new days to set.
     */
    public void setDays(String days) {
        this.days = days;
    }

    /**
     * Gets the start time of the course
     * @return String for the start ime
     */
    public String getStartTime() {
        return startTime;
    }

    /**
     * Sets the new start time of the course
     * @param startTime String for the new start time
     */
    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    /**
     * Gets the end time of the course
     * @return String of the end time
     */
    public String getEndTime() {
        return endTime;
    }

    /**
     * Sets the new end time of the course
     * @param endTime String for the end time
     */
    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    /**
     * gets the location of the course
     * @return String for the location
     */
    public String getLocation() {
        return location;
    }

    /**
     * Sets the new location of the course
     * @param location String for the new location
     */
    public void setLocation(String location) {
        this.location = location;
    }

    /**
     * Printout of the course
     * @return String output of the course object
     */
    public String toString() {
        return "ID: " + id + "\n" + dept + number + " - " + title + "\nInstructor: " + instructor + "\nDate & Time: " +
                days + "  " + startTime + " - " + endTime + "\nLocation: " + location;
    }

    /**
     * Compares class via ID
     * @param obj The other course to compare this course to.
     * @return True if id's match, False otherwise.
     */
    public boolean equals(Object obj) {
        if (obj instanceof Course c2) {
            return id == c2.id;
        }
        return false;
    }
}
