/**
 *NAME:Isabella Elge
 * DATE:9/30/25
 * ASSIGNMENT: Assignment 4- Student Course Schedule
 * CLASS: INFO 1531
 * RESOURCES: I utilized the book and the lecture videos to complete this project
 *
 * PURPOSE: The work I did added functionality to the program to add a class or filter or get a count of classes at certain times
 **/
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.function.Predicate;
import java.util.stream.Collectors;


/**
 * Database class that holds all the courses in the system
 * YOUR TODO
 *
 * Write Predicate and Streams to complete the tasks here.
 *
 */
public class ScheduleDB {
    //list that stores the courses from the loaded file
    private ArrayList<Course> courseList = new ArrayList<>();
//filters the courselist
    public ArrayList<Course> filterCourses(Predicate<Course> predicate) {
        return courseList.stream()
                .filter(predicate)
                .collect(Collectors.toCollection(ArrayList::new));
    }
//filters the courselist by classes with time of 0000
    public int countOnlineCourses() {
        return (int) courseList.stream()
                .filter(c -> c.getStartTime().equals("0:00"))
                .count();
    }
//filters the courselist for items that have the time frame of 0-12
    public int countMorningCourses() {
        return (int) courseList.stream()
                .filter(c -> {
                    try {
                        int hour = Integer.parseInt(c.getStartTime().split(":")[0]);
                        return hour > 0 && hour < 12;
                    } catch (Exception e) {
                        return false;
                    }
                })
                .count();
    }
//filters the courselist by classes that have the hours of 12-18
    public int countAfternoonCourses() {
        return (int) courseList.stream()
                .filter(c -> {
                    try {
                        int hour = Integer.parseInt(c.getStartTime().split(":")[0]);
                        return hour >= 12 && hour < 18;
                    } catch (Exception e) {
                        return false;
                    }
                })
                .count();
    }

    // filters the courselist by classes that are later than 1800 hours
    public int countEveningCourses() {
        return (int) courseList.stream()
                .filter(c -> {
                    try {
                        int hour = Integer.parseInt(c.getStartTime().split(":")[0]);
                        return hour >= 18;
                    } catch (Exception e) {
                        return false;
                    }
                })
                .count();
    }
    /**
     * Main constructor that calls the read in from text file for setup.
     */
    public ScheduleDB() {
        readInCourses();
    }

    /**
     * Gets a course via the ID from the arraylist
     * @param id int for the id
     * @return Course that matches, null if none exists
     */
    public Course getCourse(int id) {
        for (Course c : courseList) {
            if (c.getId() == id) {
                return c;
            }
        }
        return null;
    }

    /**
     * Gets a course via index from the list
     * @param index int for the index
     * @return Course
     */
    public Course getCourseViaIndex(int index) {
        return courseList.get(index);
    }

    /**
     * Returns the whole course list
     * @return ArrayList<Course> list
     */
    public ArrayList<Course> getCourseList() {
        return courseList;
    }


    /**
     * Reads in the courses from the 'courses.txt' file.
     */
    public void readInCourses() {
        try (BufferedReader in = new BufferedReader(new FileReader("courses.txt"))) {
            in.readLine(); // read past headers
            String line = in.readLine();

            while (line != null) {
                String[] tokens = line.split(",");

                Course c = new Course(Integer.parseInt(tokens[0]), Department.valueOf(tokens[1]), tokens[2], tokens[3],
                        tokens[4], tokens[5], tokens[6], tokens[7], tokens[8]);

                courseList.add(c); // add to list
                line = in.readLine(); // read next line
            }
        }
        catch(FileNotFoundException e) {
            System.out.println("File not found");
        }
        catch(IOException e) {
            System.out.println(e.getMessage());
        }
    }

}
