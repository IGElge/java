public enum Department {
    ENGL,
    MATH,
    SCIE,
    INFO,
    BSAD,
    LANG,
    CONS,
    HEAL,
    HIST,
    ARTS,
    AUTO,
    METL;
}
