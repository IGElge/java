/**
 *NAME:Isabella Elge
 * DATE:9/30/25
 * ASSIGNMENT: Assignment 4- Student Course Schedule
 * CLASS: INFO 1531
 * RESOURCES: I utilized the book and the lecture videos to complete this project
 *
 * PURPOSE: The work I did added functionality to the program to add a class or filter or get a count of classes at certain times
 **/

import java.util.ArrayList;
import java.util.Scanner;

/**
 * System runner for the Course Schedule Assignment 4 - 1531.
 */
public class ScheduleUI {
    private static Scanner input = new Scanner(System.in);
    private static ArrayList<Course> studentSchedule = new ArrayList<>();
    private static ScheduleDB db = new ScheduleDB();

    /**
     * Main method to provide menu and options
     * @param args String[] of command line arguments.
     */
    public static void main(String[] args) {

        int choice = 0;

        while (choice != 6) {
            System.out.println("*** College Course System ***");
            System.out.println("1. Add class to Schedule");
            System.out.println("2. Filter by Department");
            System.out.println("3. Filter by Day of Week");
            System.out.println("4. Filter by Instructor");
            System.out.println("5. Get Time Count");
            System.out.println("6. Exit");
            choice = getInt("Operation: ", 1, 6);
            
            switch(choice) {
                case 1 -> addClassToSchedule();
                case 2 -> filterByDept();
                case 3 -> filterByDay();
                case 4 -> filterByInstructor();
                case 5 -> courseTimeCount();
            }
	    System.out.println();
        }
    }

    /**
     * This method adds a course to the student's schedule.
     *
     * YOUR TODO
     * When we add a course we should printout the schedule. Currently we don't.
     * Using a stream printout the schedule after we add a course.
     */
    private static void addClassToSchedule() {
        //specifies that the course ID is an int
        int courseID = getInt("Enter course ID: ");
        //retrieves the course object by ID
        Course c = db.getCourse(courseID);
        //a while clause to mark if the course has already been added
        while (studentSchedule.contains(c)) {
            System.out.println("* Error, course already added to schedule.");
            //loops back and gets the course id again
            courseID = getInt("Enter course ID: ");

            c = db.getCourse(courseID);
        }
        // once the course isn't in schedule, gets to here to add
        studentSchedule.add(c);
        System.out.println("Added class to Schedule");

        //print out the schedule
        studentSchedule.stream()
                .forEach(course -> {
                    System.out.println(course);
                    System.out.println();
                });
    }

    /**
     * YOUR TODO
     *
     * This method will filter courses by department. You can have them enter
     * it in or provide a list.
     */
    private static void filterByDept() {
        //prints a header for this step
        System.out.println("***Filter by Department***");
        //creates a department list and orders them
        Department[] departments = Department.values();
        for (int i=0; i < departments.length; i++) {
            System.out.println((i+1) + ". " + departments[i]);
        }
        //prints a list of departments to chose from
        int choice = getInt("Choose Department: ", 1, departments.length);
        Department selectedDept = departments[choice-1];
//prints the courses in the department
        ArrayList<Course> filteredCourses = db.filterCourses(course -> course.getDept() == selectedDept);
        System.out.println("\n* Courses in " + selectedDept+" *");
        for (Course c : filteredCourses) {
            System.out.println(c);
            System.out.println();
        }
    }

    /**
     * YOUR TODO
     *
     * This method will filter out courses by the Day.  Users can either input the
     * days or you can provide a list that they then select from.
     */
    private static void filterByDay() {
        //prints a name for the following process
        System.out.println("***Filter by Day***");
        //gets the days or online type of class
        System.out.print("Enter in Days (Online, M, MW, W, etc): ");
        //sends this to uppercase to be read
        String day = input.nextLine().toUpperCase();

        //creates an arraylist
        ArrayList<Course> filtered = db.filterCourses(
                c -> c.getDays().toUpperCase().contains(day)
        );
//prints the courses on the day/s specified
        System.out.println("\n* Courses on " + day+" *");
        for (Course c :filtered) {
            System.out.println(c);
            System.out.println();
        }
    }

    /**
     * YOUR TODO
     *
     * This method will filter out courses by instructor. Users can either input the
     * name of the instructor or you could printout a list to select from.
     */
    private static void filterByInstructor() {
        //prints a filter by instructor headeer
        System.out.println("***Filter by Instructor***");
        //gets instructor name
        System.out.print("Enter instructor name: ");
        //puts it into lowercase
        String search = input.nextLine().toLowerCase();

        //creates an arraylist to filter the courses by the instructor
        ArrayList<Course> filtered = db.filterCourses(
                c -> c.getInstructor().toLowerCase().contains(search)
        );
//prints out the filtered results
       System.out.println("\n* Courses taught by " + search + "*");
       for (Course c :filtered) {
           System.out.println(c);
           System.out.println();
       }
    }

    /**
     * YOUR TODO
     *
     * This method prints out the count of courses that are in the morning (before 12:00pm),
     * the afternoon (after 12:00pm and before 6:00pm) and evening (after 6:00pm)
     */
    private static void courseTimeCount() {
        //prints a course time count header
        System.out.println("***Course Time Count***");
//creates a list of classes with the morning, afternoon, evening, or online tag
        int morning = db.countMorningCourses();
        int afternoon = db.countAfternoonCourses();
        int evening = db.countEveningCourses();
        int online = db.countOnlineCourses();
//prints how many classes are in the following times
        System.out.println("Morning Courses: " + morning);
        System.out.println("Afternoon Courses: " + afternoon);
        System.out.println("Evening Courses: " + evening);
        System.out.println("Online Courses: " + online);
    }

    /**
     * Helper method to get a valid int within the sent range
     * @param prompt String to print out
     * @param min smallest value
     * @param max largest value
     * @return int within the range of min and max
     */
    private static int getInt(String prompt, int min, int max) {
        while (true) {
            int value = getInt(prompt);
            if (value < min || value > max) {
                System.out.println("*Error, value must be between " + min + " and " + max);
                continue;
            }
            return value;
        }
    }

    /**
     * Helper method to get a valid integer
     * @param prompt String to print out
     * @return int number
     */
    private static int getInt(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                return Integer.parseInt(input.nextLine());
            }
            catch (Exception e) {
                System.out.println("*Error, must enter in a number.");
            }
        }
    }
}
