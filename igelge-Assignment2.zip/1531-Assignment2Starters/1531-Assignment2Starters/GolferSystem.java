/**
 * NAME: Isabella Elge
 * DATE: 9/15/2025
 * ASSIGNMENT: Assignment 2 - Golfer Stats
 * CLASS:INFO 1531
 * RESOURCES:I used the book and the lecture videos to append this preexisting file
 * PURPOSE:This file creates a menu to use to change a user inputted file (in this case GolfStats.txt)
 */
import java.util.Scanner;

/**
 * The system runner for the golf system.
 *
 * @author Lucas Hartman with modifications by Isabella Elge
 * RESOURCES: I utlized the book and the lecture videos to make adjustments to this file
 * @version 1.0.0
 */
public class GolferSystem {
    public static Scanner input = new Scanner(System.in);
    public static GolferDB db = new GolferDB();

    /**
     * YOUR TODO - add in exceptions
     * Main method to provide menu options
     * @param args array string command line arguments.
     */
    public static void main(String[] args) {
        System.out.println("*** Golfer Stat System ***");
        System.out.print("Please enter name of stat file: ");
        String file = input.nextLine();
        System.out.println("Looking for file in: " + System.getProperty("user.dir"));

        db = new GolferDB(file);
        try {
            db.readInGolfers();

            // menu for viewing, adding, deleteing
            int choice = 0;
            while (choice != 5) {
                System.out.println("\n** Main Menu **");
                System.out.println("1. View Golfer Stats");
                System.out.println("2. Add Golfer Stat");
                System.out.println("3. Add New Golfer");
                System.out.println("4. Delete Golfer");
                System.out.println("5. Exit");
                choice = getInt("Operation: ", 1, 5);

                switch (choice) {
                    case 1 -> viewGolfers();
                    case 2 -> addGolferStat();
                    case 3 -> addGolfer();
                    case 4 -> deleteGolfer();
                    case 5 -> db.writeOutGolfers();
                }
                System.out.println();
            }
	System.out.println("** Thanks for using the Golf Tracker 3000 **");
    } //Throws a catch error for anything that goes wrong (aka an unreadable file or file not found)
        catch (GolfDataException e) {
            System.out.println("ERROR: " + e.getMessage());
        }

}
    /**
     * This will print out all the golfer's and their scores with average.
     */
    public static void viewGolfers() {
        System.out.println("\n** View Golfer Stats **");
        for (Golfer g : db.getGolfers()) {
            System.out.println(g);
        }
    }

    /**
     * This will print out a list of the golfers for the user to select. Then
     * ask to add a stat or complete. When they add a stat, a number is entered
     * and added to the golfer's score list.
     */
    public static void addGolferStat() {
        System.out.println("\n** Add Golfer Stat **");
        int i = 1;
        for (Golfer g : db.getGolfers()) {
            System.out.println(i++ + ". " + g.getName());
        }
        int golfer = getInt("Select golfer: ", 1, i) - 1; // off by one - people to computer numbers
        Golfer current = db.getGolfers().get(golfer);
        int choice = 0;
        while (choice != 2) {
            System.out.println("\n* Golfer " + current.getName() + " *");
            System.out.println("1. Add Stat");
            System.out.println("2. Complete");
            choice = getInt("Operation: ", 1, 2);

            switch (choice) {
                case 1 -> {
                    int stat = getInt("Enter score: ");
                    current.addScore(stat);
                }
            }
        }
    }

    /**
     * This will get the name of a golfer and create it in the system.
     * Users will then have to go to the add stat option to add scores.
     */
    public static void addGolfer() {
        System.out.println("\n** Add Golfer **");
        System.out.print("Enter golfer name: ");
        String name = input.nextLine();

        Golfer g = new Golfer(name);

        db.addGolfer(g);
    }

    /**
     * This will print out the list of golfers and allow the user to
     * enter in a number corresponding to the golfer to delete.
     */
    public static void deleteGolfer() {
        System.out.println("\n** Delete Golfer **");
        int i = 1;
        for (Golfer g : db.getGolfers()) {
            System.out.println(i++ + ". " + g.getName());
        }
        int golfer = getInt("Select golfer: ", 1, i) - 1; // off by one - people to computer numbers

        if (db.removeGolfer(golfer)) {
            System.out.println("\nGolfer removed.");
        }
        else {
            System.out.println("\nError, couldn't remove golfer.");
        }
    }

    /**
     * Helper method to get a valid int number
     * @param prompt String to print for input prompt
     * @return valid int number.
     */
    private static int getInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Integer.parseInt(input.nextLine());
            }
            catch (NumberFormatException e) {
                System.out.println("Error, must enter a number");
            }
        }
    }

    /**
     * Helper method to get an integer number between a set range.
     * @param prompt String for the prompt to print
     * @param min int for the minimum value input can be
     * @param max int for the maximum value input can be
     * @return valid int number.
     */
    private static int getInt(String prompt, int min, int max) {
        while (true) {
            int value = getInt(prompt);
            if (value < min || value > max) {
                System.out.println("Error, must be between " + min + " and " + max);
                continue;
            }
            return value;
        }
    }
}
