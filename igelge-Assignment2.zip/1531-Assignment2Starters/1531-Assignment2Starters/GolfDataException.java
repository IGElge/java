/**
 * NAME: Isabella Elge
 * DATE: 9/15/2025
 * ASSIGNMENT: Assignment 2 - Golfer Stats
 * CLASS:INFO 1531
 * RESOURCES:I used the book and the lecture videos to create this error exception file
 * PURPOSE:This file will process errors thrown by the GolferDB and GolferSystem files and then return it as a message
 * when called by the GolferSystem.java file
 */

public class GolfDataException extends Exception {
    public GolfDataException() {
        super();
    }

    public GolfDataException(String message) {
        super(message);
    }
}