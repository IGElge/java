/**
 * NAME: Isabella Elge
 * DATE: 9/15/2025
 * ASSIGNMENT: Assignment 2 - Golfer Stats
 * CLASS:INFO 1531
 * RESOURCES:I used the book and the lecture videos to append this preexisting file
 * PURPOSE:This file defines the read and write functions to edit a user inputted file (in this case GolfStats.txt)
 */

import java.io.*;
import java.util.ArrayList;

/**
 * This class is the database for our golf stat program. It handles the list
 * of golfers and all the database actions like reading/writing the stats.
 *
 * @author Lucas Hartman with modifications by Isabella Elge
 * RESOURCES: I utilized the book and the lecture to append this file
 * @version 1.0.0
 *
 */
public class GolferDB {
    private ArrayList<Golfer> golfers = new ArrayList<>();
    private String fileName;

    /**
     * Main constructor that sets the file name up.
     *
     * @param fileName String for the file name to use for the stats.
     */
    public GolferDB(String fileName) {
        this.fileName = fileName;
    }

    /**
     * Default constructor that sets the file name to "stats.txt"
     */
    public GolferDB() {
        fileName = "stats.txt";
    }

    /**
     * Returns the list of golfers
     *
     * @return ArrayList of Golfers.
     */
    public ArrayList<Golfer> getGolfers() {
        return golfers;
    }

    /**
     * Adds a golfer to the list. Checks for duplicates via the golfer.
     *
     * @param g Golfer to add to the list
     * @return true if added successfully, false otherwise
     */
    public boolean addGolfer(Golfer g) {
        if (!golfers.contains(g)) {
            golfers.add(g);
            return true;
        }
        return false;
    }

    /**
     * Removes a golfer from list via the index.
     *
     * @param index int for the index of golfer
     * @return true if removed successfully, false otherwise
     */
    public boolean removeGolfer(int index) {
        if (index >= 0 && index < golfers.size()) {
            golfers.remove(index);
            return true;
        }
        return false;
    }

    /**
     * YOUR TODO
     *
     * This method reads in from the golfer stat text file. Then creates a golfer object
     * and puts it in the list.
     */
    /**
     * This method reads in from the golfer stat text file. Then creates a golfer object
     * and puts it in the list.
     *
     * @throws GolfDataException if the file is missing or cannot be read
     */
    //sets up a read function to get data from the .txt
    public void readInGolfers() throws GolfDataException {
        try (BufferedReader in = new BufferedReader(new FileReader(fileName))) {
            // Skip the header line
            String line = in.readLine();
    //a while statement
            while ((line = in.readLine()) != null) {
                // skip blank lines to avoid errors
                if (line.trim().isEmpty()) continue;
//creates a new line after getting the score
                String[] parts = line.split("\t");
                String name = parts[0];
                ArrayList<Integer> scores = new ArrayList<>();
//gets the score from the file and skips the name to not include it and throw errors
                for (int i = 1; i < parts.length; i++) {
                    String scoreStr = parts[i].trim();
                    //an if statment for if there is an empty score
                    if (!scoreStr.isEmpty()) {
                        //tries to add the score to the score string
                        try {
                            scores.add(Integer.parseInt(scoreStr));
                            //throws an error for invalid scores
                        } catch (NumberFormatException e) {
                            System.out.println("Skipping invalid score: " + scoreStr + " for " + name);
                        }
                    }
                }

                Golfer golfer = new Golfer(name, scores);
                golfers.add(golfer);
            }

            System.out.println("Loaded " + golfers.size() + " golfers.");
        } catch (FileNotFoundException e) {
            throw new GolfDataException("No file exists: " + fileName);
        } catch (IOException e) {
            throw new GolfDataException("Error reading golfer file: " + e.getMessage());
        }
    }


    /**
     * YOUR TODO
     * <p>
     * This method writes out the golfers back into the text file from the array list. Uses the
     * same delimiters to recreate the entire file. Don't forget the headings.
     */
    //sets up the file writer
    public void writeOutGolfers() throws GolfDataException {
        try (PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(fileName)))) {
            // Write header
            out.println("Player Name\t - \t Scores");
//gets the name and prints the scores that correspond to name
            for (Golfer g : golfers) {
                out.print(g.getName());
                for (int score : g.getScores()) {
                    out.print("\t" + score);
                }
                out.println();
            }
//prints a success message for the user
            System.out.println("Successfully wrote " + golfers.size() + " golfers to " + fileName);
        }
        //throws an error for when saving fails
        catch (IOException e) {
            throw new GolfDataException("Error saving golfer file: " + e.getMessage());
        }
    }
}
