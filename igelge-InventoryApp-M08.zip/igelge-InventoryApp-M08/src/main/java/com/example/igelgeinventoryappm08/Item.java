/**
 * NAME: Isabella Elge
 * DATE: 10/28/25
 * CLASS: INFO 1531
 * ASSIGNMENT: Assignment 8 - Inventory Management
 * RESOURCES: I utilized the lecture videos and examples for this assignment
 *
 * PURPOSE: This is the getters and setters for the item
 */
package com.example.igelgeinventoryappm08;

import java.io.Serializable;
//outlines all the attributes of the Item
public class Item implements Serializable {
    private String id;
    private String name;
    private String manufacturer;
    private double price;
    private int inventory;
    private ItemType type;
    private com.example.igelgeinventoryappm08.Image image;

    public Item() {}

    public Item(String id, String name, String manufacturer, double price, int inventory, ItemType type) {
        this.id = id;
        this.name = name;
        this.manufacturer = manufacturer;
        this.price = price;
        this.inventory = inventory;
        this.type = type;
        this.image = new com.example.igelgeinventoryappm08.Image();
    }

    // Getters & Setters
    public String getId() { return id; }
    public String getName() { return name; }
    public String getManufacturer() { return manufacturer; }
    public double getPrice() { return price; }
    public int getInventory() { return inventory; }
    public ItemType getType() { return type; }
    public com.example.igelgeinventoryappm08.Image getImage() { return image; }

    public void setId(String id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setManufacturer(String manufacturer) { this.manufacturer = manufacturer; }
    public void setPrice(double price) { this.price = price; }
    public void setInventory(int inventory) { this.inventory = inventory; }
    public void setType(ItemType type) { this.type = type; }
    public void setImage(com.example.igelgeinventoryappm08.Image image) { this.image = image; }


}
