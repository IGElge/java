/**
 * NAME: Isabella Elge
 * DATE: 10/28/25
 * CLASS: INFO 1531
 * ASSIGNMENT: Assignment 8 - Inventory Management
 * RESOURCES: I utilized the lecture videos and examples for this assignment
 *
 * PURPOSE: This is the enumeration file for the item type
 */
package com.example.igelgeinventoryappm08;

public enum ItemType {
    FOOD_DRINK, APPAREL, ACCESSORY, BOOK, SCHOOL_MATERIAL;

    @Override
    public String toString() {
        return switch (this) {
            case FOOD_DRINK -> "Food & Drink";
            case APPAREL -> "Apparel";
            case ACCESSORY -> "Accessory";
            case BOOK -> "Book";
            default -> "School Material";
        };
    }
}

