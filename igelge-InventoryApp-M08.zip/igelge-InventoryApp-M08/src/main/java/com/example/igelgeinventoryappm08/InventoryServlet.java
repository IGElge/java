/**
 * NAME: Isabella Elge
 * DATE: 10/28/25
 * CLASS: INFO 1531
 * ASSIGNMENT: Assignment 8 - Inventory Management
 * RESOURCES: I utilized the coding example version of this file
 *
 * PURPOSE: This is the servlet for the program that incorporates all the HTML with the below functionality for the MCC bookstore.
 * NOTE: I did redo this file as I was running into many issues, the comments are slightly different due to my fresh restart
 */
package com.example.igelgeinventoryappm08;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.*;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.Part;
import java.io.*;
import java.util.*;
//Starts the URL off with a /inventory

@MultipartConfig
public class InventoryServlet extends HttpServlet {
    private Map<String, Item> itemDB = new HashMap<>();
//uses a doGet to get a request and response and throws an error if encountered
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        //the action switch for the actions on the page with types like response or request
        String action = req.getParameter("action");
        if (action == null) action = "list";

        switch (action) {
            case "create" -> showCreateForm(req, resp);
            case "view" -> showItem(req, resp);
            case "searchPage" -> showSearchPage(req, resp);
            default -> listItems(req, resp);
        }
    }
//Uses the create.jsp file for the create form of new items
    private void showCreateForm(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setAttribute("pageTitle", "Add New Item");
        RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/jsp/create.jsp");
        dispatcher.forward(req, resp);
    }
//shows all items, if there are no items itll send the user back to the index page
    private void showItem(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String itemId = req.getParameter("itemID");
        Item item = itemDB.get(itemId);
        if (item == null) {
            resp.sendRedirect(req.getContextPath() + "/index.jsp");
            return;
        }
        //uses the view.jsp file for viewing the items
        req.setAttribute("item", item);
        req.setAttribute("pageTitle", item.getName());
        RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/jsp/view.jsp");
        dispatcher.forward(req, resp);
    }
//the inventory list method using list.jsp for the formatting
    private void listItems(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setAttribute("items", itemDB.values());
        req.setAttribute("pageTitle", "Inventory List");
        RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/jsp/list.jsp");
        dispatcher.forward(req, resp);
    }
//search page for users to search, uses the search.jsp file for formattign
    private void showSearchPage(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setAttribute("pageTitle", "Search Inventory");
        RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/jsp/search.jsp");
        dispatcher.forward(req, resp);
    }
//sends the updated list to inventory using post
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String action = req.getParameter("action");
        if ("create".equals(action)) {
            createItem(req, resp);
        } else {
            resp.sendRedirect(req.getContextPath() + "/inventory?action=list");
        }
    }
//create item method
    private void createItem(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String id = req.getParameter("id");
        if (id == null || id.isEmpty()) id = UUID.randomUUID().toString();
//gets the name manufacturer price inventory and type
        String name = req.getParameter("name");
        String manufacturer = req.getParameter("manufacturer");
        double price = Double.parseDouble(req.getParameter("price"));
        int inventory = Integer.parseInt(req.getParameter("inventory"));
        ItemType type = ItemType.valueOf(req.getParameter("type"));
//assigns the item with its attributes
        Item newItem = new Item(id, name, manufacturer, price, inventory, type);
//allows for an add image option for the item
        Part imageFile = req.getPart("imageFile");
        if (imageFile != null && imageFile.getSize() > 0) {
            newItem.setImage(processImage(imageFile));
        }
//stores all my items in my inventory
        synchronized (this) {
            itemDB.put(newItem.getId(), newItem);
        }

        resp.sendRedirect(req.getContextPath() + "/inventory?action=view&itemID=" + newItem.getId());
    }

    //processes the image on the item
    private com.example.igelgeinventoryappm08.Image processImage(Part file) throws IOException {
        try (InputStream in = file.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096];
            int read;
            while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);

            com.example.igelgeinventoryappm08.Image img = new com.example.igelgeinventoryappm08.Image();
            img.setName(file.getSubmittedFileName());
            img.setContents(out.toByteArray());
            return img;
        }
    }
}
