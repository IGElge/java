/**
 * NAME:Isabella Elge
 * DATE: 10/7/25
 * CLASS: INFO 1531
 * ASSIGNMENT: Assignment 5 - Appointment System
 * RESOURCES: I utilized the book and the lecture+slides to complete this assignment
 *
 * PURPOSE: My work completed this file to make the addAppointment and modifyAppointment methods work
 * with the date and time functionality needed.
 */

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * System file for the INFO 1531 - Assignment 5 - Appointment System
 *
 * @author Lucas Hartman
 * @version 1.0.0
 *
 *
 */
public class ScheduleSystem {
    private static Scanner input = new Scanner(System.in);
    private static Map<Integer, Appointment> appointments = new HashMap<>();

    /**
     * Main that runs the system.
     *
     * @param args String command line
     */
    public static void main(String[] args) {
        testData();

        int choice = 0;
        while (choice != 5) {
            System.out.println("*** Appointment Schedule System ***");
            System.out.println("1. View Appointment");
            System.out.println("2. Add Appointment");
            System.out.println("3. Modify Appointment");
            System.out.println("4. Delete Appointment");
            System.out.println("5. Exit");
            choice = getInt("Operation: ", 1, 5);
            System.out.println();
            switch (choice) {
                case 1 -> viewAppointment();
                case 2 -> addAppointment();
                case 3 -> modifyAppointment();
                case 4 -> deleteAppointment();
            }
            System.out.println();
        }
    }

    /**
     * Print out an appointment based on id.
     */
    private static void viewAppointment() {
        System.out.println("** View Appointment **");
        int id = getInt("Enter Appointment Id: ");
        Appointment app = appointments.get(id);

        System.out.println();
        if (app == null) {
            System.out.println("* Appointment not found *");
        } else {
            System.out.println(app);
        }
    }

    /**
     * Method to add a new appointment to the system.
     * Makes sure the day is not Saturday or Sunday and within business hours
     * of 8am and 6pm.
     * <p>
     * YOUR TODO
     * Fill out this method that gets input for date/time for start and then
     * hours/minutes for how long the appointment goes for. Then create an "end" LocalDateTime and adjust
     * Make sure start date/time is not on a Saturday or Sunday and that it is between the hours of 8am and 6pm.
     * <p>
     * With valid dates, then ask for a description about the appointment. Then create a new Appointment object.
     * <p>
     * Lastly add it to the map via a random ID and print out the ID and information - the Appointment object has
     * a toString() method.
     * <p>
     * The random ID code is provided to you below to create the IDs.
     */
    private static LocalDateTime getValidDateTime() {
        //prints a start date and time message header
        System.out.println("* Start Date/Time *");
//while statement for the date and time
        while (true) {
            //prints a get date message
            System.out.print("Enter date(MM/DD/YYYY): ");
            //shortens the date to just match 9 instead of 09
            String dateStr = input.nextLine().trim();
//sets an if statement to make sure the date matches the required format
            if (!dateStr.matches("\\d{2}/\\d{2}/\\d{4}")) {
                //prints the error
                System.out.println("Error on date, please follow required format.");
                continue;
            }
//gets the time but demands 24hour format
            System.out.print("Enter time 24 Hour format(HH:MM): ");
            //trims the inputted time down
            String timeStr = input.nextLine().trim();

            //tries to see if the date and time matches the format
            try {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm");
                LocalDateTime dateTime = LocalDateTime.parse(dateStr + " " + timeStr, formatter);
                //prints it if it does
                return dateTime;
                //prints an error if it does not
            } catch (Exception e) {
                System.out.println("Error on date or time, please follow required format.");
            }
        }
    }

//gets the length of the appointment
    private static int[] getLength() {
//uses a while statment to get the appointment length
        while (true) {
            System.out.print("Enter length of appointment(H:M): ");
            String inputLength = input.nextLine().trim();
//Ensures the format matches the required form
            if (!inputLength.matches("\\d{1,2}:\\d{1,2}")) {
                System.out.println("Error on length, please follow required format.");
                continue;
            }
//separates the minutes and hours with :
            try {
                String[] parts = inputLength.split(":");
                int hours = Integer.parseInt(parts[0]);
                int minutes = Integer.parseInt(parts[1]);
//returns hours and minutes in the form
                return new int[]{hours, minutes};
                //catches if the minutes and hours are longer than intended
            } catch (Exception e) {
                System.out.println("Error on length, please follow required format.");
            }
        }
    }




//the add appointment method
    private static void addAppointment() {
        System.out.println("** Add Appointment **");
//calls for the previous method for date and time
        LocalDateTime start = getValidDateTime();
//gets the length of the meeting from getlength
        int[] length = getLength();
//calculates the end of the appointment
        LocalDateTime end = start.plusHours(length[0]).plusMinutes(length[1]);
//gets the day of the week and writes that to the getdayofweek from the user time (that we got with localdatetime)
        DayOfWeek day = start.getDayOfWeek();
        //gets the start hour from the current user time
        int startHour = start.getHour();

        //sets boolean statements for weekends and outside office hours
        boolean isWeekend = (day == DayOfWeek.SATURDAY || day == DayOfWeek.SUNDAY);
        boolean outOfHours = (startHour < 8 || startHour >= 18);
//prints an error for trying to schedule on saturday or sunday
        if (isWeekend) {
            System.out.println("Error, we aren't open Saturday or Sunday.");
            return;
        }
//prints error for users trying to schedule outside of business hours
        if (outOfHours) {
            System.out.println("Error, we are available between 8am(08:00) and 6pm(18:00)");
            return;
        }
//prints an error if the appointment ends after 1800
        if (end.getHour() > 18 || (end.getHour() == 18 && end.getMinute() > 0)) {
            System.out.println("Error, appointment must end by 6pm(18:00)");
            return;
        }
//gets a description of the appointment
        System.out.println("Enter description:");
        String description = input.nextLine().trim();

        // Generate unique ID
        int id = (int)(Math.random() * 900000) + 100000;
        while (appointments.containsKey(id)) {
            id = (int)(Math.random() * 900000) + 100000;
        }
//writes the appointment variables (start, end, and description and adds the ID to the newApp)
        Appointment newApp = new Appointment(start, end, description);
        appointments.put(id, newApp);
//prints the appointment added message then prints the ID
        System.out.println("* Appointment Added *");
        System.out.println("ID: " + id);
        //prints the appointment information after the ID
        System.out.println(newApp);
    }

    /**
     * Allows the user to modify an ID after finding it in the system.
     * Just like the add, the appointment modification must be valid date/time.
     * Not on a saturday or sunday and between 8am and 6pm for time.
     *
     * YOUR TODO
     *
     * The menu work is done, you just need to code in the switch statement for 1 or 2.
     * Case 1 is a totally new date/time and length.
     * Case 2 is a new length
     */
    private static void modifyAppointment() {
        //prints modify appointment then gets the appointment ID from the user
        System.out.println("** Modify Appointment **");
        int id = getInt("Enter Appointment Id: ");
//calls for the appointment that the user provided
        Appointment app = appointments.get(id);
//if statement for if the appointment does not exist
        if (app == null) {
            System.out.println("* Error, Appointment not found *");
            return;
        }
//prints the appointment and then a menu for editing
        System.out.println(app);
        System.out.println("1. New Date/Time and Length");
        System.out.println("2. New Length");
        int choice = getInt("Operation: ", 1, 2);
//uses a switch for the 3 different options
        switch (choice) {
            //sets a new date and time
            case 1 -> {
                //gets the start from getvaliddatetime
                LocalDateTime newStart = getValidDateTime();
                //gets the length of the new appointment
                int[] newLength = getLength();
//puts it in format
                LocalDateTime newEnd = newStart.plusHours(newLength[0]).plusMinutes(newLength[1]);
//gets the day and hour
                DayOfWeek day = newStart.getDayOfWeek();
                int startHour = newStart.getHour();
                //prints errors if the appointment is on weekends or outside of hours
                boolean isWeekend = (day == DayOfWeek.SATURDAY || day == DayOfWeek.SUNDAY);
                boolean outOfHours = (startHour < 8 || startHour >= 18);
//prints error messages for those errors
                if (isWeekend) {
                    System.out.println("Error, we aren't open Saturday or Sunday.");
                    return;
                }

                if (outOfHours) {
                    System.out.println("Error, we are available between 8am(08:00) and 6pm(18:00)");
                    return;
                }
//prints an error if the appointment does not end by 1800
                if (newEnd.getHour() > 18 || (newEnd.getHour() == 18 && newEnd.getMinute() > 0)) {
                    System.out.println("Error, appointment must end by 6pm(18:00)");
                    return;
                }
//prints the new start and end and then updates the appointment
                app.setStart(newStart);
                app.setEnd(newEnd);
                //prints success message and the appointment
                System.out.println("* Appointment Updated *");
                System.out.println(app);
            }
//changes the length of the appointment
            case 2 -> {
                int[] newLength = getLength();
                LocalDateTime currentStart = app.getStart();
                //adds the time from the getlength to start to get the end time
                LocalDateTime newEnd = currentStart.plusHours(newLength[0]).plusMinutes(newLength[1]);
//errors for if the end time goes past 1800
                if (newEnd.getHour() > 18 || (newEnd.getHour() == 18 && newEnd.getMinute() > 0)) {
                    System.out.println("Error, appointment must end by 6pm(18:00)");
                    return;
                }
//prints the newly updated appointment
                app.setEnd(newEnd);
                System.out.println("* Appointment Updated *");
                System.out.println(app);
            }
        }
    }


    /**
     * Deletes an appointment based on the ID.
     */
    private static void deleteAppointment() {
        System.out.println("** Delete Appointment **");
        int id = getInt("Enter Appointment Id: ");

        Appointment app = appointments.get(id);

        if (app == null) {
            System.out.println("* Error, Appointment not found *");
            return;
        }

        appointments.remove(id);
        System.out.println("* Appointment Deleted *");
    }

    /**
     * Helper method that gets a valid int based on a range.
     * @param prompt String to print for prompt
     * @param min int for minimum value
     * @param max int for maximum value
     * @return int within the range of min and max
     */
    private static int getInt(String prompt, int min, int max) {
        while (true) {
            int value = getInt(prompt);
            if (value < min || value > max) {
                System.out.println("Error, number out of range.");
            }
            else {
                return value;
            }
        }
    }

    /**
     * Method to get a valid integer from the Scanner.
     * @param prompt String to print for a prompt
     * @return int value
     */
    private static int getInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Integer.parseInt(input.nextLine());
            }
            catch (NumberFormatException e) {
                System.out.println("Error, must enter a number.");
            }
        }
    }

    /**
     * method to insert some sample appointment data to text out.
     */
    private static void testData() {

        appointments.put(123456, new Appointment(
                LocalDateTime.of(2025, 5, 9, 9, 0),
                LocalDateTime.of(2025, 5, 9, 10, 30),
                "Need help on C++ homework assignment 6."));

        appointments.put(456789, new Appointment(
                LocalDateTime.of(2025, 4, 29, 13, 15),
                LocalDateTime.of(2025, 4, 29, 14, 0),
                "Debugging issue with Java 1, assignment 3."
        ));

        appointments.put(456123, new Appointment(
                LocalDateTime.of(2025, 5, 1, 11, 0),
                LocalDateTime.of(2025, 5, 1, 12, 0),
                "Review Module 7 of Java 2."
        ));

        appointments.put(321456, new Appointment(
                LocalDateTime.of(2025, 4, 1, 15, 30),
                LocalDateTime.of(2025, 4, 1, 16, 0),
                "Python 1 module 4 help."
        ));
    }

}
