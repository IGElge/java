/**
 * NAME: Isabella Elge
 * DATE: 10/21/25
 * CLASS: INFO 1531
 * ASSIGNMENT: Assignment 7 - Inventory Management
 * RESOURCES: I utilized the lecture videos and examples for this assignment
 *
 * PURPOSE: This is the servlet for the program that incorporates all the HTML with the below functionality for the MCC bookstore.
 */
//Imports packages and other import tools for the below servlet
package com.example.igelgeinventoryappm7;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import jakarta.servlet.ServletException;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

//Starts the URL off with a /inventory
@WebServlet(urlPatterns = {"/inventory"})
@MultipartConfig()
public class InventoryServlet extends HttpServlet {
    private Map<String, Item> itemDB = new HashMap<>();
//uses a doGet to get a request and response and throws an error if encountered
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
//the action switch for the actions on the page with types like response or request
        resp.setContentType("text/html");
        String action = req.getParameter("action");
        if (action == null) action = "list";

        switch (action) {
            case "create" -> createForm(resp);
            case "view" -> viewItem(req, resp);
            case "searchPage" -> searchPage(resp);
            case "search" -> searchItems(req, resp);
            default -> listItems(resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
//the action parameter from the form submission
        String action = req.getParameter("action");
        //if the form was submitted
        if ("create".equals(action)) {
            createItem(req, resp);
        } else {
            resp.sendRedirect("inventory?action=list");
        }
    }


    // view item method
    private void viewItem(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        PrintWriter out = resp.getWriter();
        String itemId = req.getParameter("itemID");
        Item current = itemDB.get(itemId);
//if the item cant be found the program will print an error
        if (current == null) {
            out.println(siteHeader("Item Not Found"));
            out.println("<p>Item not found!</p>");
            out.println(siteFooter());
            return;
        }

        out.println(siteHeader(current.getName()));
//formats the image (this is identical to things below with more indepth comments)
        if (current.hasImage()) {
            String extension = current.getImage().getName();
            extension = extension.substring(extension.lastIndexOf('.') + 1);
            out.println("<aside class='imageRight'>" +
                    "<img src='data:image/" + extension + ";base64," +
                    current.getImage().getBase64Image() + "' width='200'></aside>");
    } else {
            out.println("<aside class='imageRight'><img src='Images/noimage.png' alt='No Image'></aside>");
        }
//outputs the item information
        out.println("<h2>" + current.getName() + "</h2>" +
                "<p><strong>Manufacturer:</strong> " + current.getManufacturer() + "</p>" +
                "<p><strong>Type:</strong> " + current.getType() + "</p>" +
                "<p><strong>Price:</strong> $" + current.getPrice() + "</p>" +
                "<p><strong>Inventory:</strong> " + current.getInventory() + "</p>");
        out.println(siteFooter());
    }

    //creates the HTML for the entire creation page with a dropdown for the item type
    private void createForm(HttpServletResponse resp) throws IOException {
        PrintWriter out = resp.getWriter();
        out.println(siteHeader("Add New Item"));
        out.println("<h2>Add New Item</h2>" +
                "<form method='POST' action='inventory' enctype='multipart/form-data'>" +
                "<input type='hidden' name='action' value='create'>" +
                "ID: <input type='text' name='id' placeholder='MM8874'><br>" +
                "Name: <input type='text' name='name'><br>" +
                "Manufacturer: <input type='text' name='manufacturer'><br>" +
                "Price: <input type='number' step='0.01' name='price'><br>" +
                "Inventory: <input type='number' name='inventory'><br>" +
                "Type: <select name='type'>" +
                "<option value='FOOD_DRINK'>Food & Drink</option>" +
                "<option value='APPAREL'>Apparel</option>" +
                "<option value='ACCESSORY'>Accessory</option>" +
                "<option value='BOOK'>Book</option>" +
                "<option value='SCHOOL_MATERIAL'>School Material</option>" +
                "</select><br>" +
                "Image: <input type='file' name='imageFile'><br>" +
                "<input type='submit' value='Add Item'>" +
                "</form>");
        out.println(siteFooter());
    }
//the create item method
    private void createItem(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
//gets the ID of the item
        String id = req.getParameter("id");
        //If the ID is left empty it give it a random ID
        if (id == null || id.isEmpty()) id = UUID.randomUUID().toString();
//Gets the name of the item
        String name = req.getParameter("name");
        //gets manufacturer
        String manufacturer = req.getParameter("manufacturer");
        //gets the price
        double price = Double.parseDouble(req.getParameter("price"));
        //gets how many of the item
        int inventory = Integer.parseInt(req.getParameter("inventory"));
        //gets the item type
        ItemType type = ItemType.valueOf(req.getParameter("type"));
//puts all of the Item information to the newitem tag
        Item newItem = new Item(id, name, manufacturer, price, inventory, type);
//allows for an image to be attached to the item
        Part imageFile = req.getPart("imageFile");
        if (imageFile != null && imageFile.getSize() > 0) {
            Image img = processImage(imageFile);
            newItem.setImage(img);
        }
//synchronizes the item to the DB
        synchronized (this) {
            itemDB.put(newItem.getId(), newItem);
        }
//redirects users to view the new item
        resp.sendRedirect("inventory?action=view&itemID=" + newItem.getId());
    }

    //a method to process the image
    private Image processImage(Part file) throws IOException {
        //uses try with to not drain resources and closes after stream has ended
        try (InputStream in = file.getInputStream();
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            //buffer for the chunks of the input stream
            byte[] buffer = new byte[4096];
            int read;
            //read into a buffer and then write out that buffer
            while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);

            //create a new image object to hold the picutre
            Image img = new Image();
            //set the file name to the image
            img.setName(file.getSubmittedFileName());
            img.setContents(out.toByteArray());

            //return the image
            return img;
        }
    }

//a list items method for the entire inventory list
    private void listItems(HttpServletResponse resp) throws IOException {
        PrintWriter out = resp.getWriter();
        //prints the site header
        out.println(siteHeader("Inventory List"));
        //prints a smaller header for the items
        out.println("<h2>Inventory Items</h2>");
//if the database is empty prints no items in the system
        if (itemDB.isEmpty()) {
            out.println("<p>No items in the system.</p>");
            //if items found in the database
        } else {
            for (Item item : itemDB.values()) {
                //creates a section for the item on the page
                out.println("<section>");
                //formats the item image to be on this page
                if (item.hasImage()) {
                    String extension = item.getImage().getName();
                    extension = extension.substring(extension.lastIndexOf('.') + 1);
                    out.println("<img src='data:image/" + extension + ";base64," +
                            item.getImage().getBase64Image() + "' width='100'><br>");
                    //an else case for no image attached
                } else {
                    out.println("<img src='Images/noimage.png' width='100'><br>");
                }
                //prints the item info under the item name and picture
                out.println("<a href='inventory?action=view&itemID=" + item.getId() + "'>" + item.getName() + "</a><br>" +
                        item.getType() + " - $" + item.getPrice() + "</section>");
            }
        }

        out.println(siteFooter());
    }

//Websites search function
    private void searchPage(HttpServletResponse resp) throws IOException {
        PrintWriter out = resp.getWriter();
        out.println(siteHeader("Search Inventory"));
        out.println("<h2>Search Inventory</h2>");
        out.println("<form method='GET' action='inventory'>" +
                "<input type='hidden' name='action' value='search'>" +
                "<input type='text' name='query' placeholder='Enter item name or type' required>" +
                "<input type='submit' value='Search'>" +
                "</form>");
        out.println(siteFooter());
    }
//an *extra method* for searching items on the web page
    private void searchItems(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        //starts printwriter
        PrintWriter out = resp.getWriter();
        //stores the query name (basically whatever the user wrote)
        String query = req.getParameter("query");
        //if results ere found prints the success message with the query provided
        out.println(siteHeader("Search Results for: " + query));
        //Prints a search results header
        out.println("<h2>Search Results</h2>");
//boolean for if the query finds something
        boolean found = false;
        //loops through the items based on the query
        for (Item item : itemDB.values()) {
            //searches with various cases
            if (item.getName().toLowerCase().contains(query.toLowerCase()) ||
                    item.getType().toString().toLowerCase().contains(query.toLowerCase())) {
//if there was a matching query found
                found = true;
                //Start a new section for it on the page
                out.println("<section>");
                //prints the image associated with the item found
                if (item.hasImage()) {
                    String extension = item.getImage().getName();
                    extension = extension.substring(extension.lastIndexOf('.') + 1);
                    out.println("<img src='data:image/" + extension + ";base64," +
                            item.getImage().getBase64Image() + "' width='100'><br>");
                //prints without image if there is no image
                } else {
                    out.println("<img src='Images/noimage.png' width='100'><br>");
                }
                //creates a clickable link for the item and prints all of its information on the search site
                out.println("<a href='inventory?action=view&itemID=" + item.getId() + "'>" + item.getName() + "</a><br>" +
                        item.getType() + " - $" + item.getPrice() + "</section>");
            }
        }
//if no items were found prints a no items found message with the user input after it
        if (!found) {
            out.println("<p>No items found matching: " + query + "</p>");
        }

        out.println(siteFooter());
    }

    //formats the sites headers and footers
    private String siteHeader(String title) {
        return "<!DOCTYPE html><html><head><title>" + title + "</title>" +
                "<link rel='stylesheet' href='style.css'></head><body>" +
                "<header><h1>MCC Bookstore Inventory</h1></header>" +
                "<nav>" +
                "<a href='index.jsp'>Home</a>" +
                "<a href='inventory?action=list'>View Inventory</a>" +
                "<a href='inventory?action=create'>Add New Item</a>" +
                "<a href='inventory?action=searchPage' style='margin-left:20px;'>Search</a>" +
                "</nav><main>";
    }

    private String siteFooter() {
        return "</main><footer>&copy; MCC Bookstore 2025</footer></body></html>";
    }
}
