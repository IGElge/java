/**
 * NAME: Isabella Elge
 * DATE: 10/21/25
 * CLASS: INFO 1531
 * ASSIGNMENT: Assignment 7 - Inventory Management
 * RESOURCES: I utilized the lecture videos and examples for this assignment
 *
 * PURPOSE: This is the getters and setters for the item
 */
package com.example.igelgeinventoryappm7;
import java.io.Serializable;
//outlines all the attributes of the Item
public class Item implements Serializable {
    private String id;
    private String name;
    private String manufacturer;
    private double price;
    private int inventory;
    private ItemType type;
    private Image image;

    public Item() {}

    public Item(String id, String name, String manufacturer, double price, int inventory, ItemType type) {
        this.id = id;
        this.name = name;
        this.manufacturer = manufacturer;
        this.price = price;
        this.inventory = inventory;
        this.type = type;
        this.image = new Image();
    }

    // Getters & Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getManufacturer() { return manufacturer; }
    public void setManufacturer(String manufacturer) { this.manufacturer = manufacturer; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public int getInventory() { return inventory; }
    public void setInventory(int inventory) { this.inventory = inventory; }

    public ItemType getType() { return type; }
    public void setType(ItemType type) { this.type = type; }

    public Image getImage() { return image; }
    public void setImage(Image image) { this.image = image; }

    public boolean hasImage() {
        return image != null && image.getName().length() > 0 && image.getContents().length > 0;
    }
}
