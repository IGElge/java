/**
 * NAME: Isabella Elge
 * DATE: 10/21/25
 * CLASS: INFO 1531
 * ASSIGNMENT: Assignment 7 - Inventory Management
 * RESOURCES: I utilized the coding example version of this file
 *
 * PURPOSE: This is the servlet for the program that incorporates all the HTML with the below functionality for the MCC bookstore.
 */
package com.example.igelgeinventoryappm7;

import java.util.Base64;

public class Image {
    private String name;
    private byte[] contents;
    private String base64Image;

    public Image() {
        name = "";
        contents = new byte[0];
        base64Image = "";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public byte[] getContents() {
        return contents;
    }

    public void setContents(byte[] contents) {
        this.contents = contents;
        base64Image = Base64.getEncoder().encodeToString(contents);
    }

    public String getBase64Image() {
        return base64Image;
    }

}
